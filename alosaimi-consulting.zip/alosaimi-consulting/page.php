<?php
/**
 * Standard page template with Elementor support.
 */

get_header();
?>
<main id="aoc-page-content" class="aoc-page-content bg-aoc-black text-aoc-white overflow-x-clip">
    <?php aoc_render_wp_page_content(); ?>
</main>
<?php
get_footer();

