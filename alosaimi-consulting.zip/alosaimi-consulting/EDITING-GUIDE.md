# Al Osaimi Consulting WordPress Theme - Editing Guide

## How to Install the Theme

1. Copy the `wp-content/themes/alosaimi-consulting/` folder to your WordPress installation's `wp-content/themes/` directory.
2. In WordPress admin, go to **Appearance > Themes** and activate **Al Osaimi Consulting**.
3. Visit any admin page once — the theme will automatically create a "Home" page and seed all default content (services, projects, clients, certificates).
4. Go to **Settings > Reading** and confirm "A static page" is selected with "Home" as the front page.

---

## How to Edit Content

### Text Content (Hero, About, CEO Speech, Contact)

1. In the admin sidebar, click **Al Osaimi Content > Global Settings**.
2. Use the tabs at the top to navigate between sections:
   - **Hero** — Edit the scrolling banner text (English and Arabic).
   - **About & CEO** — Edit the About section title, paragraphs, CEO name, title, and speech. Each paragraph of the CEO speech goes on a new line.
   - **Services** — Edit the services section title and intro paragraphs. Individual services are managed separately (see below).
   - **Projects** — Edit the projects section title.
   - **Contact** — Edit the contact section title.
   - **Social Links** — Update LinkedIn, Instagram, Facebook, and BeFound URLs.
   - **Media & Logo** — Upload replacement logos, favicon, hero poster, and about section image from the Media Library.
   - **Misc** — Edit the bottom bar text ("A FOUNDATION OF TRUST").
3. Click **Save Changes** on each tab.

### Services

1. Go to **Al Osaimi Content > Services**.
2. Click any service to edit it. You can change:
   - **Title** (English) — the post title field.
   - **Arabic title** — in the Service Fields box below.
   - **Short description** (English & Arabic) — shown on the service cards.
   - **Full description** (English & Arabic) — shown in the expanded services modal.
   - **Location** (English & Arabic).
   - **Main service image** — click "Choose image" to pick from the Media Library.
3. To reorder services, change the **Order** field (Page Attributes box, right sidebar). Lower numbers appear first.
4. To add a new service, click **Add Service**.
5. To remove a service, move it to Trash.

### Projects

1. Go to **Al Osaimi Content > Projects**.
2. Click any project to edit:
   - **Title** (English) — the post title field.
   - **Arabic title**, **Year**, **Location** (English & Arabic), **Description** (English & Arabic) — in the Project Fields box.
   - **Main project image** — click "Choose image".
   - **Gallery images** — click "Choose gallery images" to select multiple images for the project slider.
3. **Project categories** (Residential, Medical, Gas Stations) are managed from the **Project Categories** panel in the sidebar when editing a project, or from the taxonomy page.
4. To add a new category, go to the category management page and add it with a display key (e.g., `COMMERCIAL`), Arabic label, and English label.
5. Reorder projects using the **Order** field.

### Clients (Logo Marquee)

1. Go to **Al Osaimi Content > Clients**.
2. Each client has a title (alt text), an optional website URL, and a logo image.
3. Click "Choose image" to upload or replace a client logo from the Media Library.
4. To add a new client, click **Add Client** and fill in the title, logo, and optional URL.
5. Reorder using the **Order** field.

### Certificates (Accreditation Logos)

1. Go to **Al Osaimi Content > Certificates**.
2. Same as clients — title, URL, and logo image.
3. These appear in the "Architect of Record" service's accreditations panel.

---

## How to Edit Images

All images should be uploaded to the **WordPress Media Library** (Media > Library).

- **Service images**: Edit the service > click "Choose image" in the Main service image field.
- **Project images**: Edit the project > click "Choose image" for the main image, or "Choose gallery images" for the slider.
- **Client logos**: Edit the client > click "Choose image".
- **Certificate logos**: Edit the certificate > click "Choose image".
- **Logo, Favicon, Hero poster, About image**: Go to **Al Osaimi Content > Global Settings > Media & Logo** tab.
- **Hero video**: Currently uses a built-in video. To replace it, you would need to update the source file in `assets/source/` or use the JSON override in **Al Osaimi Settings > Content override JSON** to point `media.hero_video` to a new URL.

---

## How to Edit the Header

The header contains the logo and navigation.

### Logo
Go to **Al Osaimi Content > Global Settings > Media & Logo** tab. Upload separate logos for desktop (full white logo) and mobile (compact logo).

### Navigation Menu
1. Go to **Appearance > Menus**.
2. Create a new menu and assign it to the **Primary Navigation** location.
3. Add **Custom Links** with hash URLs for each section:
   - Home: `#home`
   - About: `#about`
   - Services: `#services`
   - Projects: `#projects`
   - Contact: `#contact`
4. The theme will automatically apply the correct styling and active-state highlighting.
5. If no menu is assigned, the theme uses its built-in default navigation.

---

## How to Edit the Footer / Bottom Bar

The bottom bar text ("A FOUNDATION OF TRUST") is editable from **Al Osaimi Content > Global Settings > Misc** tab.

Social media links in the hero section are editable from **Al Osaimi Content > Global Settings > Social Links** tab.

---

## How to Edit Forms

The contact form is built into the theme and submits via WordPress AJAX to the admin email.

- **Recipient email**: Go to **Appearance > Al Osaimi Settings** and change the "Contact recipient email" field.
- **Form labels** (First Name, Last Name, Email, Message, Send Message) are part of the bilingual translation system and use the default labels. To customize, use the **Content override JSON** field in Al Osaimi Settings.

---

## How to Edit Buttons and Links

- **Social media links**: Al Osaimi Content > Global Settings > Social Links tab.
- **Navigation links**: Appearance > Menus (or the built-in defaults).
- **"Learn More" / "Read More" buttons**: These are part of the translation system. Contact labels and button text can be overridden via the JSON override if needed.
- **Certificate links**: Edit each certificate's URL field in Al Osaimi Content > Certificates.
- **Client links**: Edit each client's URL field in Al Osaimi Content > Clients.

---

## How to Add, Remove, or Reorder Sections

### Using Elementor (Free)
If Elementor is installed, you can:
1. Go to **Pages > Home** and click "Edit with Elementor".
2. Use the Elementor Shortcode widget with these codes to place sections:
   - `[aoc_section name="hero"]`
   - `[aoc_section name="about"]`
   - `[aoc_section name="services"]`
   - `[aoc_section name="clients"]`
   - `[aoc_section name="projects"]`
   - `[aoc_section name="contact"]`
3. You can reorder, remove, or add sections between them.
4. Use `[aoc_homepage]` to render the complete homepage.

### Without Elementor
The section order is defined in `front-page.php`. The default order is: Intro > Top Nav > Hero > About > Services > Clients > Projects > Contact > Bottom Bar.

### Adding New Pages
1. Go to **Pages > Add New**.
2. Give it a title and add content using the WordPress block editor (Gutenberg).
3. The page will use the theme's dark styling automatically.
4. For a full-width page, select the "Elementor Full Width" template from the Page Attributes panel.

---

## How to Manage Pages

- **Homepage**: Set in Settings > Reading as the static front page.
- **New pages**: Pages > Add New. Each page inherits the theme's dark design.
- **Page templates**: "Default" for standard pages, "Elementor Full Width" for Elementor-built pages.

---

## Free Plugins Used

| Plugin | Purpose | Required? |
|--------|---------|-----------|
| **None required** | The theme works without any plugins | — |
| **Elementor (Free)** | Optional: visual page building and section reordering | Optional |
| **Contact Form 7** or **WPForms Lite** | Optional: if you prefer a plugin-based contact form over the built-in one | Optional |

The theme is designed to work without any plugins. The built-in CMS system handles all content management. Elementor is optional and only needed if you want to visually reorder sections or build new pages with a drag-and-drop editor.

---

## Tracking & Analytics

Go to **Appearance > Al Osaimi Settings** to configure:
- Google Tag Manager ID
- Google Analytics ID
- Microsoft Clarity ID
- Google Search Console verification
- Bing verification

---

## Bilingual Support (English / Arabic)

The website supports both English and Arabic with full RTL layout. Users switch languages using the EN/AR toggle in the navigation bar. All content fields have both English and Arabic versions.

---

## Design Preservation Checklist

- [x] All colors preserved (dark navy #003087, black, gold #CAB64B, white)
- [x] Typography preserved (Darker Grotesque, Inter Tight, Fustat for Arabic)
- [x] All animations preserved (scroll animations, fade-in, slide, circle draw, card dealing)
- [x] Glassmorphism effects preserved (backdrop-blur, semi-transparent cards)
- [x] Custom cursor preserved (gold circle, hover state)
- [x] Intro overlay animation preserved (circle draw on page load)
- [x] Hero video with scrolling banner preserved
- [x] Service carousel with drag-to-scroll preserved
- [x] Service detail modal with sidebar navigation preserved
- [x] Project modal with category sidebar, gallery, lightbox preserved
- [x] Client logo marquee (infinite scroll) preserved
- [x] Contact form with bilingual labels preserved
- [x] Responsive layout (desktop, tablet, mobile) preserved
- [x] RTL/Arabic layout preserved
- [x] Fixed navigation with active section highlighting preserved
- [x] Bottom bar with section-aware visibility preserved
- [x] "Learn More" bar expansion animation for projects preserved

## Editability Checklist

- [x] All text content is editable from the admin
- [x] All images can be replaced from the Media Library
- [x] Services can be added, removed, reordered
- [x] Projects can be added, removed, reordered, categorized
- [x] Clients can be added, removed, reordered
- [x] Certificates can be added, removed, reordered
- [x] Navigation menu is managed from Appearance > Menus
- [x] Logo and favicon can be replaced
- [x] Social links are editable
- [x] Contact form recipient is configurable
- [x] Tracking IDs are configurable
- [x] Bottom bar text is editable
- [x] Hero banner text is editable
- [x] About section text is editable
- [x] CEO speech is editable
- [x] Section titles are editable (Services, Projects, Contact)
- [x] New pages can be created using the same design system
