<?php
/**
 * Elementor compatibility helpers.
 */

if (!defined('ABSPATH')) {
    exit;
}

function aoc_is_elementor_active(): bool
{
    return did_action('elementor/loaded') || defined('ELEMENTOR_VERSION');
}

function aoc_post_uses_elementor(?int $post_id = null): bool
{
    $post_id = $post_id ?: get_queried_object_id();

    return $post_id > 0 && 'builder' === get_post_meta($post_id, '_elementor_edit_mode', true);
}

function aoc_is_elementor_editor_request(): bool
{
    return isset($_GET['elementor-preview']) || isset($_GET['elementor_library']) || isset($_GET['action']) && 'elementor' === sanitize_key(wp_unslash($_GET['action']));
}

function aoc_should_render_wp_page_content(?int $post_id = null, bool $include_plain_content = true): bool
{
    $post_id = $post_id ?: get_queried_object_id();

    if ($post_id <= 0) {
        return false;
    }

    if (aoc_post_uses_elementor($post_id) || aoc_is_elementor_editor_request()) {
        return true;
    }

    if (!$include_plain_content) {
        return false;
    }

    $post = get_post($post_id);

    return $post instanceof WP_Post && '' !== trim((string) $post->post_content);
}

function aoc_render_wp_page_content(): void
{
    if (!have_posts()) {
        return;
    }

    while (have_posts()) {
        the_post();
        the_content();
    }

    wp_reset_postdata();
}

function aoc_elementor_homepage_content(): string
{
    return implode("\n\n", [
        '[aoc_section name="top-nav"]',
        '[aoc_section name="hero"]',
        '[aoc_section name="about"]',
        '[aoc_section name="services"]',
        '[aoc_section name="clients"]',
        '[aoc_section name="projects"]',
        '[aoc_section name="contact"]',
        '[aoc_section name="bottom-bar"]',
    ]);
}

function aoc_find_homepage_id(): int
{
    $front_page_id = absint(get_option('page_on_front'));
    if ($front_page_id && 'page' === get_post_type($front_page_id)) {
        return $front_page_id;
    }

    $existing = get_page_by_path('home');
    if ($existing instanceof WP_Post && 'page' === $existing->post_type) {
        return (int) $existing->ID;
    }

    $pages = get_posts([
        'post_type' => 'page',
        'post_status' => ['publish', 'draft', 'private'],
        'posts_per_page' => 1,
        'title' => 'Home',
        'fields' => 'ids',
    ]);

    return $pages ? (int) $pages[0] : 0;
}

function aoc_ensure_elementor_homepage(): int
{
    $home_id = aoc_find_homepage_id();

    if (!$home_id) {
        $home_id = wp_insert_post([
            'post_type' => 'page',
            'post_status' => 'publish',
            'post_title' => 'Home',
            'post_name' => 'home',
            'post_content' => aoc_elementor_homepage_content(),
            'page_template' => 'templates/elementor-full-width.php',
        ]);
    }

    if (is_wp_error($home_id) || !$home_id) {
        return 0;
    }

    update_post_meta((int) $home_id, '_wp_page_template', 'templates/elementor-full-width.php');

    if ('page' !== get_option('show_on_front') || absint(get_option('page_on_front')) !== (int) $home_id) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', (int) $home_id);
    }

    return (int) $home_id;
}

function aoc_maybe_create_elementor_homepage(): void
{
    if (!is_admin() || !current_user_can('manage_options')) {
        return;
    }

    aoc_ensure_elementor_homepage();
}
add_action('admin_init', 'aoc_maybe_create_elementor_homepage');
add_action('after_switch_theme', 'aoc_ensure_elementor_homepage');

function aoc_elementor_register_category($elements_manager): void
{
    if (!method_exists($elements_manager, 'add_category')) {
        return;
    }

    $elements_manager->add_category('aoc-sections', [
        'title' => __('Al Osaimi Sections', 'alosaimi-consulting'),
        'icon' => 'fa fa-plug',
    ]);
}
add_action('elementor/elements/categories_registered', 'aoc_elementor_register_category');

function aoc_elementor_register_widgets($widgets_manager): void
{
    if (!class_exists('\Elementor\Widget_Base') || !class_exists('\Elementor\Controls_Manager')) {
        return;
    }

    if (!class_exists('AOC_Elementor_Section_Widget')) {
        class AOC_Elementor_Section_Widget extends \Elementor\Widget_Base
        {
            public function get_name()
            {
                return 'aoc_section';
            }

            public function get_title()
            {
                return __('Al Osaimi Section', 'alosaimi-consulting');
            }

            public function get_icon()
            {
                return 'eicon-section';
            }

            public function get_categories()
            {
                return ['aoc-sections'];
            }

            protected function register_controls()
            {
                $this->start_controls_section('content_section', [
                    'label' => __('Section', 'alosaimi-consulting'),
                    'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
                ]);

                $this->add_control('section_name', [
                    'label' => __('Choose section', 'alosaimi-consulting'),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'hero',
                    'options' => [
                        'hero' => __('Hero', 'alosaimi-consulting'),
                        'about' => __('About', 'alosaimi-consulting'),
                        'services' => __('Services', 'alosaimi-consulting'),
                        'clients' => __('Clients', 'alosaimi-consulting'),
                        'projects' => __('Projects', 'alosaimi-consulting'),
                        'contact' => __('Contact', 'alosaimi-consulting'),
                        'top-nav' => __('Top navigation', 'alosaimi-consulting'),
                        'bottom-bar' => __('Bottom bar', 'alosaimi-consulting'),
                    ],
                ]);

                $this->end_controls_section();
            }

            protected function render()
            {
                $settings = $this->get_settings_for_display();
                echo aoc_render_section_markup((string) ($settings['section_name'] ?? 'hero')); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            }
        }
    }

    if (method_exists($widgets_manager, 'register')) {
        $widgets_manager->register(new \AOC_Elementor_Section_Widget());
    } elseif (method_exists($widgets_manager, 'register_widget_type')) {
        $widgets_manager->register_widget_type(new \AOC_Elementor_Section_Widget());
    }
}
add_action('elementor/widgets/register', 'aoc_elementor_register_widgets');
