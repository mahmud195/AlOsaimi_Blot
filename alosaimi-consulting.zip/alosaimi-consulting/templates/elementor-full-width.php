<?php
/**
 * Template Name: Elementor Full Width
 * Template Post Type: page
 */

get_header();
?>
<main id="aoc-elementor-full-width" class="aoc-elementor-full-width bg-aoc-black text-aoc-white overflow-x-clip">
    <?php aoc_render_wp_page_content(); ?>
</main>
<?php
get_footer();

